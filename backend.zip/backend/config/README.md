This folder contains the configureation for the DB along with the Setup for the server
