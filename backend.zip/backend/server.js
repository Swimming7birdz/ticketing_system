const express = require("express");
const dotenv = require("dotenv");
const os = require("os");
const path = require("path");

const FRONTEND_BUILD_PATH = path.join(__dirname, "../frontend/build"); // PUT INTO ENV VARS PLEASE

// Load environment variables
dotenv.config();

const app = express();
//temp changes made by adi for no-cahche global middleware for all resposnses
app.use((req, res, next) => {
        res.setHeader("Cache-Control","no-store, no-cache, must-revalidate, max-age=0");
        res.setHeader("Pragma", "no-cache");
        res.setHeader("Expires","0");
        next();
});

app.use(express.static(FRONTEND_BUILD_PATH));   //changes made by Adi to try to test for caching
// Load setup for middleware and database
require("./config/setup")(app);

// Load routes
require("./routes")(app);

app.get("*", (req, res) => {
  res.sendFile(path.join(FRONTEND_BUILD_PATH, "index.html"));
});

const PORT = process.env.PORT || 3000;
const HOSTNAME = os.hostname();

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://${HOSTNAME}:${PORT}`);
});